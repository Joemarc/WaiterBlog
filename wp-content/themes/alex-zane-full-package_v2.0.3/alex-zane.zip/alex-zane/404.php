<?php
/**
 * 404 Page template.
 *
 * @package alex-zane
 * @since 1.0.0
 *
 */
get_header(); ?>

<!-- 404 page content -->

<?php get_footer();
