<?php 
header("Content-type: text/css; charset: UTF-8");
echo cs_get_option( 'custom-css' );