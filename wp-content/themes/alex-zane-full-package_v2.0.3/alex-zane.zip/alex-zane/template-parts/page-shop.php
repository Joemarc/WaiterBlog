<?php
/**
 *
 * Shop page
 * @since 1.0
 * @version 1.2.0
 *
 */

?>

<main class="e-main-content">
    <?php the_content(); ?>
</main>
