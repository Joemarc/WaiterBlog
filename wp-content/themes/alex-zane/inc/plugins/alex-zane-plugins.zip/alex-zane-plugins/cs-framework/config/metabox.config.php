<?php 
if ( ! defined( 'ABSPATH' ) ) { die; } // Cannot access pages directly.
/**
 *
 * CSFramework Metabox Config
 *
 * @since 1.0
 * @version 1.0
 *
 */
$metaboxes        = array();

$metaboxes[]      = array(
  'id'            => '_custom_page_options',
  'title'         => 'Custom Options',
  'post_type'     => 'page', // or post or CPT
  'context'       => 'normal',
  'priority'      => 'default',
  'sections'      => array(

    // begin section
    array(
      'name'      => 'general_header_options',
      'title'     => 'General Header Options',
      'fields'    => array(

            array(
               'id'    => 'show_banner',
               'type'  => 'switcher',
               'title' => 'Show Banner',
               'default'    => true
            ),
            array(
              'id'      => 'fixed_header',
              'type'    => 'switcher',
              'title'   => 'Fixed Header',
              'default' => false
            ),
            array(
                  'id'    => 'style_header',
                  'type'  => 'select',
                  'title' => 'Style Header',
                  'options'       => array(
                      'dark'      => 'Dark',
                      'light'          => 'Light',
                      'dark_bg'   => 'Dark & Background',
                   ),
                  'default' => 'dark',
            ),
            array(
               'id'    => 'alt_title',
               'type'  => 'text',
               'title' => 'ALternative Title (For Top Banner)',
               'dependency' => array( 'show_banner', '==', 'true' )
            ),
            array(
                'id'    => 'alt_subtitle',
                'type'  => 'text',
                'title' => 'ALternative Subtitle (For Top Banner)',
                'dependency' => array( 'show_banner', '==', 'true' )
            ),
            array(
                'id'    => 'alt_image',
                'type'  => 'image',
                'title' => 'Image  (For Top Banner)',
                'dependency' => array( 'show_banner', '==', 'true' )
            ),

            
      ),
    ),
    array(
      'name'      => 'menu_header_options',
      'title'     => 'Menu Header Options',
      'fields'    => array(
        array(
              'id'    => 'color_menu',
              'type'  => 'color_picker',
              'title' => 'Color Menu',
        ),
      ),
    ),
    array(
      'name'      => 'footer_options',
      'title'     => 'Footer Options',
      'fields'    => array(
        array(
           'id'    => 'fixed_footer',
           'type'  => 'switcher',
           'title' => 'Fixed footer',
           'default'    => false
        ),
        array(
              'id'    => 'style_footer',
              'type'  => 'select',
              'title' => 'Style Footer',
              'options'        => array(
                  'dark'      => 'Dark',
                  'light'     => 'Light',
               ),
              'default' => 'dark',
        ),
      ),
    ),


  ),
);

CSFramework_Metabox::instance( $metaboxes );