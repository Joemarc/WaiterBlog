<?php if ( ! defined( 'ABSPATH' ) ) { die; } // Cannot access pages directly.
// ===============================================================================================
// -----------------------------------------------------------------------------------------------
// FRAMEWORK SETTINGS
// -----------------------------------------------------------------------------------------------
// ===============================================================================================
$settings      = array(
  'menu_title' => 'Theme Options',
  'menu_type'  => 'add_menu_page',
  'menu_slug'  => 'cs-framework',
  'ajax_save'  => false,
);

//images_sizes
$images_sizes = array('gallery_image_big','full');
$images_sizes = array_merge($images_sizes, 
					array_diff( get_intermediate_image_sizes(), array("gallery_image_big") ) 
				);


// ===============================================================================================
// -----------------------------------------------------------------------------------------------
// FRAMEWORK OPTIONS
// -----------------------------------------------------------------------------------------------
// ===============================================================================================
$options        = array();

// ----------------------------------------
// General option section 
// ----------------------------------------

$options[]      = array(
  'name'        => 'general',
  'title'       => 'General',
  'icon'        => 'fa fa-globe',

  // begin: fields
  'fields'      => array(

    array(
      'id'      => 'fixed_header',
      'type'    => 'switcher',
      'title'   => 'Fixed Header',
      'label'   => 'Yes, Please do it.',
      'default' => false
    ),
  	array(
  	    'id'    => 'alt_image',
  	    'type'  => 'image',
  	    'title' => 'Image  (For Top Banner)',
  	),
    //Site logo image
    array(
    	'id'      => 'logo_image',
    	'type'    => 'upload',
    	'title'   => 'Site Logo Image',
    	'desc'    => 'Output image logo.',
    	'default'    => T_IMG.'/logo.svg',
    ),

    array(
      'id'      => 'site_favico_16x16',
      'type'    => 'image',
      'title'   => 'Browser Favicon (16x16)',
      'desc'    => 'Upload Favicon icon of size 16x16.',
        'settings'      => array(
          'upload_type'  => 'image',
          'default' => get_template_directory_uri().'/assets/images/favicon.png',
        ),    

    ),

  ) // end: fields
);


// ----------------------------------------
// Blog option
// ----------------------------------------
$options[]      = array(
	'name'        => 'blog_page',
	'title'       => 'Blog',
	'icon'        => 'fa fa-rss',
	// begin: fields
	'fields'      => array(

		array(
		  'id'             => 'style_blog',
		  'type'           => 'select',
		  'title'          => 'Style Blog',
		  'options'        => array(
		    ''             => esc_html__('Full Width (Default)','alex-zane'),
		    'timeline'     => esc_html__('TimeLine','alex-zane'),
		  ),
		),

		// show sidebar
		array(
			'id'      => 'show_sidebar',
			'type'    => 'checkbox',
			'title'   => 'Show sidebar',
			'label'   => 'yes',
			'default' => true
		),

	), // end: fields
);


// ----------------------------------------
// Footer option section 
// ----------------------------------------
$options[]      = array(
  'name'        => 'footer',
  'title'       => 'Footer',
  'icon'        => 'fa fa-arrow-down',

  // begin: fields
  'fields'      => array(
	//Footer Text
	array(
	  'id'       => 'footer_text',
	  'type'     => 'wysiwyg',
	  'title'    => 'Footer Content*',
	  'settings' => array(
	    'textarea_rows' => 5,
	    'media_buttons' => false,
	  ),
	  'default'    => '&copy; Alex Zane ' . date('Y') . '. All rights reserved.',
	)
   
  
  ) // end: fields
);

// ----------------------------------------
// Socials API Configuration
// ----------------------------------------
$options[]      = array(
  'name'        => 'socials_share',
  'title'       => 'Socials Share',
  'icon'        => 'fa fa-facebook',

  // begin: fields
  'fields'      => array(

  	array(
  	  'id'              => 'socials_share_options',
  	  'type'            => 'group',
  	  'title'           => 'Socials Share Button',
  	  'button_title'    => 'Add New',
  	  'accordion_title' => 'Add New Field',
  	  'fields'          => array(

  	  	array(
  	  	  'id'      => 'social_icon',
  	  	  'type'    => 'icon',
  	  	  'title'   => 'Icon Field',
  	  	  'default' => 'fa fa-heart',
  	  	),
  	  	
  	  	array(
  	  	  'id'    => 'social_link', // this is must be unique
  	  	  'type'  => 'text',
  	  	  'title' => 'Link Field',
  	  	),


  	  ),
  	),

	
  ) // end: fields
);

// ----------------------------------------
// Custom CSS code                    -
// ----------------------------------------
$options[]      = array(
    'name'        => 'custom_css',
    'title'       => 'Custom CSS',
    'icon'        => 'fa fa-css3',
    'fields'      => array(
        array(
            'id'         => 'custom-css',
            'desc'       => 'Only CSS code, without tag &lt;style&gt;.',
            'type'       => 'textarea',
            'title'      => 'Custom CSS code',
            'attributes' => array(
              'placeholder' => 'Paste your code here ...',
                'rows'      => 20,
            ),
        )
    )
);

// ----------------------------------------
// 404 Page
// ----------------------------------------
$options[]      = array(
  'name'        => 'error_page',
  'title'       => '404 Page',
  'icon'        => 'fa fa-bolt',

  // begin: fields
  'fields'      => array(
	array(
		'id'      => 'error_title',
		'type'    => 'text',
		'title'   => 'Error title',
		'default' => 'Oops! That page can&rsquo;t be found.',
	),
	array(
		'id'      => 'error_message',
		'type'    => 'textarea',
		'title'   => 'Error Message*',
		'default' => 'It looks like nothing was found at this location. Maybe try one of the links below or a search?',
	),
	
  ) // end: fields
);

// ------------------------------
// backup                       -
// ------------------------------
$options[]   = array(
  'name'     => 'backup_section',
  'title'    => 'Backup',
  'icon'     => 'fa fa-shield',

  // begin: fields
  'fields'   => array(

	array(
		'type'    => 'notice',
		'class'   => 'warning',
		'content' => 'You can save your current options. Download a Backup and Import.',
	),
	
	array(
		'type'    => 'backup',
	),

  )  // end: fields
);

// ------------------------------
// Documentation                    -
// ------------------------------
// $options[]   = array(
//   'name'     => 'documentation_section',
//   'title'    => 'Documentation',
//   'icon'     => 'fa fa-info-circle',
  
//   'fields'   => array(

//     array(
//       'type'    => 'heading',
//       'content' => 'Documentation'
//     ),
//     array(
//       'type'    => 'content',
//       'content' => 'To view the documentation, go to <a href="#" target="_blank">documentation page</a>.',
//     ),

//   )
// );

CSFramework::instance( $settings, $options );