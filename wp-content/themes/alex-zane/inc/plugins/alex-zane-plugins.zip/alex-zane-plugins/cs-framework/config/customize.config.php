<?php if ( ! defined( 'ABSPATH' ) ) { die; } // Cannot access pages directly.
// ===============================================================================================
// -----------------------------------------------------------------------------------------------
// CUSTOMIZE SETTINGS
// -----------------------------------------------------------------------------------------------
// ===============================================================================================
$options              = array();

// -----------------------------------------
// Customize Panel Options Fields          -
// -----------------------------------------
$options[]            = array(
  'name'              => 'noho_color_panel',
  'title'             => 'Colors',
  'description'       => 'NOHO color panel',
  'priority'          => '30',
  'sections'          => array(

    // begin: section
    array(
      'name'          => 'general',
      'title'         => 'General',
      'settings'      => array(

        array(
          'name'      => 'background_color',
          'default'   => '',
          'control'   => array(
            'type'    => 'cs_field',
            'options' => array(
              'type'  => 'color_picker',
              'title' => 'Background color',
            ),
          ),
        ),

        array(
          'name'      => 'header_bg',
          'default'   => '',
          'control'   => array(
            'type'    => 'cs_field',
            'options' => array(
              'type'  => 'color_picker',
              'title' => 'Background Header Color',
            ),
          ),
        ),

        array(
          'name'      => 'g_text_color',
          'default'   => '',
          'control'   => array(
            'type'    => 'cs_field',
            'options' => array(
              'type'  => 'color_picker',
              'title' => 'Global Color Text',
            ),
          ),
        ),

        array(
          'name'      => 'color_link',
          'default'   => '',
          'control'   => array(
            'type'    => 'cs_field',
            'options' => array(
              'type'  => 'color_picker',
              'title' => 'Link Color',
            ),
          ),
        ),

        array(
          'name'      => 'color_link_hover',
          'default'   => '',
          'control'   => array(
            'type'    => 'cs_field',
            'options' => array(
              'type'  => 'color_picker',
              'title' => 'Link Color Hover',
            ),
          ),
        ),

        

        array(
          'name'      => 'other_color',
          'default'   => '',
          'control'   => array(
            'type'    => 'cs_field',
            'options' => array(
              'type'  => 'color_picker',
              'title' => 'Colors of Other Elements',
            ),
          ),
        ),


      ),
    ),
    // end: section

  ),
  // end: sections

);

CSFramework_Customize::instance( $options );



//data-color="yellow"
//data-color="green"
//data-color="red"
//data-color="dark"
//data-color="blue"
//data-color="orange"
//data-color="purple"
//data-color="pink"
//data-color="green-light"
//data-color="red-dark"
//data-color="blue-light"
//data-color="orchid"
//data-color="pink-light"
//data-color="princeton"
//data-color="sandy"
//data-color="rhodamine"
