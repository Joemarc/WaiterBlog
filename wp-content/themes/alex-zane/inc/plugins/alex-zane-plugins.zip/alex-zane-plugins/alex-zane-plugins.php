<?php
/*
Plugin Name: Alex Zane Plugins
Version: 2.0.3
Description: Includes Codestar Framework and Visual Composer Shortcodes
*/

// add in constant name path
defined( 'EF_ROOT')		or  define( 'EF_ROOT', dirname(__FILE__));

defined( 'T_URI' )      or  define( 'T_URI',  get_template_directory_uri() );
defined( 'T_IMG' )		or 	define(	'T_IMG',	T_URI . '/assets/images' );

defined( 'T_PATH' )     or  define( 'T_PATH', get_template_directory() );
defined( 'FUNC_PATH' )  or  define( 'FUNC_PATH', T_PATH . '/inc' );

if(!class_exists('ALEXZANE_Plugins')) {

	class ALEXZANE_Plugins {

		
		public function __construct() { 

			if ( !function_exists( 'is_plugin_active' ) ) {
			  include_once( ABSPATH . 'wp-admin/includes/plugin.php' ); // Require plugin.php to use is_plugin_active() below
			}

			if ( is_plugin_active( 'js_composer/js_composer.php' ) ) {

				require_once( WP_PLUGIN_DIR . '/js_composer/js_composer.php');
				// init settings and custom shortcode for visual composer
				//require_once( EF_ROOT .'/composer/init.php');

				add_action('admin_init', array($this, 'alex_zane_init') );
				add_action('wp', array($this, 'alex_zane_init') );

				add_action( 'admin_print_scripts-post.php', array($this, 'vc_enqueue_scripts'), 99);
				add_action( 'admin_print_scripts-post-new.php', array($this, 'vc_enqueue_scripts'), 99);

			}

		}

		//include custom shortcodes
		public function alex_zane_init() {

			// init vc
			require_once( EF_ROOT .'/composer/init.php');

		}

		//include scripts
		public function vc_enqueue_scripts() {
		  $assets_js = plugins_url('/composer/js', __FILE__);
		  wp_enqueue_script( 'vc-script', $assets_js .'/vc-script.js' ,  array(), '1.0.0', true );
		}


	} // end of class

	// ingegration cs framework
	require_once( EF_ROOT .'/cs-framework/cs-framework.php');
	define( 'CS_ACTIVE_FRAMEWORK', true );
	define( 'CS_ACTIVE_METABOX',   true );
	define( 'CS_ACTIVE_SHORTCODE', false );
	define( 'CS_ACTIVE_CUSTOMIZE', false );

	// include functions
	require_once( EF_ROOT .'/includes/functions_plugins.php');

	new ALEXZANE_Plugins;
} // end of class_exists

