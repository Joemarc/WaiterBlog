<?php 
/*
**
** Functions for Alex Zane Plugins
**
*/


// php custom css for one page
add_action('wp_ajax_dynamic_css', 'alex_zane_dynamic_css');
add_action('wp_ajax_nopriv_dynamic_css', 'alex_zane_dynamic_css');
function alex_zane_dynamic_css() {
  require_once T_PATH . '/assets/css/custom.css.php';
  exit;
}


