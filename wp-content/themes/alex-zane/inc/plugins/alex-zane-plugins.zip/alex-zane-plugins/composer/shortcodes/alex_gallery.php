<?php 
/*
** Alex Zane Gallery Shortcode
** Version: 1.0.0 
*/

vc_map( array(
	'name'                    => esc_html__( 'Alex Zane Gallery', 'js_composer' ),
	'base'                    => 'alex_zane_gallery',
	'content_element'         => true,
	'show_settings_on_create' => false,
	'category' 				  => esc_html__( 'From Alex Zane', 'js_composer' ),
	'description'             => esc_html__( 'Simple Images Gallery (deprecated)', 'js_composer'),
	'params'          => array(
		array(
			'type'        => 'attach_images',
			'heading'     => 'Image Event',
			'param_name'  => 'images',
			'admin_label' => true,
			'description' => 'Upload your image.'
		),
		array(
			'type' => 'dropdown',
			'heading' => esc_html__( 'Column', 'js_composer' ),
			'param_name' => 'width',
			'value' => array(
				esc_html__( '2 columns - 1/6', 'js_composer' ) => '1/6',
				esc_html__( '3 columns - 1/4', 'js_composer' ) => '1/4',
				esc_html__( '4 columns - 1/3', 'js_composer' ) => '1/3',
			),
			'group' => esc_html__( 'Configuration', 'js_composer' ),
			'description' => esc_html__( 'Select column width.', 'js_composer' ),
			'std' => '1/6',
		),
		array(
			'type' => 'textfield',
			'heading' => esc_html__( 'Count Images', 'js_composer' ),
			'param_name' => 'count',
			'group' => esc_html__( 'Configuration', 'js_composer' ),
			'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'js_composer' ),
			'value' => '',
		),
		array(
			'type' => 'textfield',
			'heading' => esc_html__( 'Extra class name', 'js_composer' ),
			'param_name' => 'el_class',
			'group' => esc_html__( 'Configuration', 'js_composer' ),
			'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'js_composer' ),
			'value' => '',
		),
		array(
			'type' => 'css_editor',
			'heading' => esc_html__( 'CSS box', 'js_composer' ),
			'param_name' => 'css',
			'group' => esc_html__( 'Design options', 'js_composer' ),
		),
	) //end params
) );

class WPBakeryShortCode_alex_zane_gallery extends WPBakeryShortCode {

	protected function content( $atts, $content = null ) {

		extract( shortcode_atts( array(
			'images' => '',
			'el_class' 	=> '',
			'count'    => '',
			'width'         => '1/6',
			'css' 			=> ''
		), $atts ) );

		// width column
		$width_class = array(
			'1/6' => 'col-md6 col-sm-6 col-xs-12',
			'1/4' => 'col-md4 col-sm-4 col-xs-12',
			'1/3' => 'col-md3 col-sm-3 col-xs-12'
		);

		// el class
		$css_classes = array(
			$this->getExtraClass( $el_class ),
			'masonry',
			'gallery',
			'row'
		);

		$css_class = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, implode( ' ', array_filter( $css_classes ) ), $this->settings['base'], $atts );

		// custum css
		$css_class .= vc_shortcode_custom_css_class( $css, ' ' );

		// custum class
		$css_class .= (!empty($css_class)) ? ' '.$css_class : '';

		// default image
		$default_src = vc_asset_url( 'vc/no_image.png' );

		// image config

		$image_sizes  = array(
			array('570','380'),
			array('570','570'),
			array('570','356'),
			array('570','321'),
			array('570','380'),
			array('570','570'),
			array('570','380'),
			array('570','356'),
			array('570','321'),
			array('570','380'),
			array('570','380'),
			array('570','380'),
			array('570','356'),
			array('570','321'),
			array('570','380'),
			array('570','356'),
			array('570','321'),
			);

		//create array
		$images = explode( ',', $images );
		$count = $count ? $count : count($images);
		$images = array_slice($images, 0, $count);
		// output
		ob_start();
		?>

		<!-- Row -->
		<?php if (!empty($images)) { ?>
		<div class="<?php echo esc_attr( $css_class ); ?>">
			
			<?php 
			$int = 0;
			foreach ( $images as $i => $image ) {
				if ($int > 16) {
					$int = 0;
				}
				$large_img_src = wp_get_attachment_image_src( $image , 'full'  );
				if ( $image > 0 ) {
					$attachment = get_post( $image );
					$caption = $attachment->post_excerpt ? $attachment->post_excerpt : $attachment->post_title;
					$img = wp_get_attachment_image_src( $image , $image_sizes[$int] );
					$thumbnail = '<img src="' . esc_attr( $img[0] ) . '" />';
				} else {
					$large_img_src = $default_src;
					$thumbnail = '<img src="' . esc_attr( $default_src ) . '" />';
				}
				?>

				<!-- Grid Item-->
				<figure class="grid-item <?php echo esc_attr($width_class[$width]); ?>">
					<a href="<?php echo esc_attr($large_img_src[0] ); ?>" data-size="<?php echo esc_attr($large_img_src[1]);?>x<?php echo esc_attr($large_img_src[2]);?>">
						<?php echo $thumbnail; ?>
					</a>
					<figcaption ><?php echo esc_html($caption); ?></figcaption>
				</figure>

				<?php $int++; } ?>
			
		</div>
		<?php } ?>
		<!-- Root element of PhotoSwipe. Must have class pswp. -->
		<div class="pswp" tabindex="-1" role="dialog" aria-hidden="true">
		    <!-- Background of PhotoSwipe. 
		         It's a separate element as animating opacity is faster than rgba(). -->
		    <div class="pswp__bg"></div>
		    <!-- Slides wrapper with overflow:hidden. -->
		    <div class="pswp__scroll-wrap">
		        <!-- Container that holds slides. 
		            PhotoSwipe keeps only 3 of them in the DOM to save memory.
		            Don't modify these 3 pswp__item elements, data is added later on. -->
		        <div class="pswp__container">
		            <div class="pswp__item"></div>
		            <div class="pswp__item"></div>
		            <div class="pswp__item"></div>
		        </div>
		        <!-- Default (PhotoSwipeUI_Default) interface on top of sliding area. Can be changed. -->
		        <div class="pswp__ui pswp__ui--hidden">
		            <div class="pswp__top-bar">
		                <!--  Controls are self-explanatory. Order can be changed. -->
		                <div class="pswp__counter"></div>
		                <button class="pswp__button pswp__button--close" title=" <?php echo esc_attr('Close (Esc)','alex-zane');?>"></button>
		                <button class="pswp__button pswp__button--share" title=" <?php echo esc_attr('Share','alex-zane');?>"></button>
		                <button class="pswp__button pswp__button--fs" title=" <?php echo esc_attr('Toggle fullscreen','alex-zane');?>"></button>
		                <button class="pswp__button pswp__button--zoom" title=" <?php echo esc_attr('Zoom in/out','alex-zane');?>"></button>
		                <!-- Preloader demo http://codepen.io/dimsemenov/pen/yyBWoR -->
		                <div class="pswp__preloader">
		                    <div class="pswp__preloader__icn">
		                      <div class="pswp__preloader__cut">
		                        <div class="pswp__preloader__donut"></div>
		                      </div>
		                    </div>
		                </div>
		            </div>
		            <div class="pswp__share-modal pswp__share-modal--hidden pswp__single-tap">
		                <div class="pswp__share-tooltip"></div> 
		            </div>
		            <button class="pswp__button pswp__button--arrow--left" title=" <?php echo esc_attr('Previous (arrow left)','alex-zane'); ?>">
		            </button>
		            <button class="pswp__button pswp__button--arrow--right" title=" <?php echo esc_attr('Next (arrow right)','alex-zane'); ?>">
		            </button>
		            <div class="pswp__caption">
		                <div class="pswp__caption__center"></div>
		            </div>
		        </div>
		    </div>
		</div>
	<!-- /Root element of PhotoSwipe. Must have class pswp. -->

		<?php 
		return  ob_get_clean();
	}

}
