<?php 
/*
** Vertical Shortcode
** Version: 1.0.0 
*/


vc_map( array(
	'name'                    => __( 'Vertical Slider', 'js_composer' ),
	'base'                    => 'alex_vertical_slider',
	'as_parent'               => array('only' => 'alex_vertical_slider_item'),
	'content_element'         => true,
	'show_settings_on_create' => false,
	'category' 				  => __( 'From Alex Zane', 'js_composer' ),
	'description'             => __( 'Simple Slider Image and Text', 'js_composer'),
	'js_view'                 => 'VcColumnView',
	'params'          => array(
		array(
			'type' => 'dropdown',
			'heading' => __( 'Style', 'js_composer' ),
			'value' => array(
				esc_html__( 'Default', 'js_composer' ) => '',
				esc_html__( 'Inside (Image and Background Image)', 'js_composer' ) => 'inside',
			),
			'admin_label' => true,
			'param_name' => 'type',
			'description' => __( 'Select icon library.', 'js_composer' ),
		),
		array(
			'type' => 'dropdown',
			'heading' => __( 'JavaScript scrolling', 'js_composer' ),
			'value' => array(
				esc_html__( 'Enable', 'js_composer' )  => 'enable',
				esc_html__( 'Disable', 'js_composer' ) => 'disable'
			),
			'admin_label' => true,
			'param_name' => 'js_scroll',
			'description' => __( 'Select icon library.', 'js_composer' ),
		),
		array(
			'type' => 'css_editor',
			'heading' => __( 'CSS box', 'js_composer' ),
			'param_name' => 'css',
			'group' => __( 'Design options', 'js_composer' ),
		),
		array(
			'type' => 'textfield',
			'heading' => __( 'Extra class name', 'js_composer' ),
			'param_name' => 'el_class',
			'description' => __( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'js_composer' ),
			'value' => '',
		),
	) //end params
) );

class WPBakeryShortCode_alex_vertical_slider extends WPBakeryShortCodesContainer {

	protected function content( $atts, $content = null) {

		extract( shortcode_atts( array(
			'style'     => '',
			'js_scroll' => 'enable',
			'el_class'  => '',
			'css'       => ''
		), $atts ) );

		global $alex_shortcode_items;
		$alex_shortcode_items = array();

		$width_class = 'content fullpage transition';
		$css_class = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, $width_class, $this->settings['base'], $atts );

		// custum css
		$css_class .= vc_shortcode_custom_css_class( $css, ' ' );

		// custum class
		$css_class .= (!empty($el_class)) ? ' ' . $el_class : '';
		if( $js_scroll == 'disable' ) {
			$css_class .= ' jsScrollOff';
		} else {
			$css_class .= ' jsScrollOn';
		}

		//check style
		$cover_titles = 'cover-titles';
		if ($style == 'inside') {
			$cover_titles = 'cover-titles-2';
		}
		
		// output
		ob_start();
		do_shortcode( $content );
		?>
		<div class="<?php echo esc_attr( $css_class ); ?>">
			<?php foreach ($alex_shortcode_items as $key=>$shortcode) { 
				$shortcode_atts = (object) $shortcode['atts'];
				$class_active = ($key == 0) ? ' active' : ''; 

				// custum class
				$class_active .= (!empty($shortcode_atts->el_class)) ? ' '.$shortcode_atts->el_class : '';

				$image_bg = $image_inside = '';
				if (!empty($shortcode_atts->image)) {
					$image_attributes = wp_get_attachment_image_src( $shortcode_atts->image, 'full' ); // returns an array
					$alt = get_post_meta($shortcode_atts->image, '_wp_attachment_image_alt', true);
					$image_bg = ' style="background-image: url(' . esc_attr( $image_attributes[0] ) . ');"';
				}

				if (!empty($shortcode_atts->image_inside)) {
					$image_attributes = wp_get_attachment_image_src( $shortcode_atts->image_inside, 'full' ); // returns an array
					$alt_inside = get_post_meta($shortcode_atts->image_inside, '_wp_attachment_image_alt', true);
					$image_inside_src = $image_attributes[0];
				}
				?>
				<div class="section" id="section<?php echo esc_attr($key+1); ?>"<?php echo $image_bg; ?> >
					<div class="darker<?php if ($style == 'inside') echo ' medium'; ?>"></div>
					<div class="border">
						<div class="frames">
		                    <div></div>
		                    <div></div>
		                    <div></div>
		                    <div></div>
	                	</div>
						<div class="corners">
		                    <div></div>
		                    <div></div>
		                </div>
					</div>
					<div class="<?php echo esc_attr($cover_titles); ?>">
							
							<?php if ($style == 'inside' && $image_inside_src) { ?>
							<div class="right-block col-md-8 col-sm-8 col-xs-12">
								<img src="<?php echo esc_attr( $image_inside_src );?>" alt="<?php echo esc_attr( $alt_inside ); ?>">
							</div>
				            <div class="left-block col-md-4 col-sm-4 col-xs-12 align-right">
				            <?php } else { ?>
				            <div class="align-left">	
					        <?php } ?>

								<?php if (!empty($shortcode_atts->subtitle)){ ?>
								<p><?php echo esc_html($shortcode_atts->subtitle); ?></p>
								<?php } ?>

								<?php if (!empty($shortcode_atts->title)){ ?>
									<h3 class="title"><?php echo esc_html($shortcode_atts->title); ?></h3>
								<?php } ?>

						        <?php if (!empty($shortcode['content'])){ ?>
					            	<?php echo wpautop( do_shortcode( $shortcode['content'] ) ); ?>
					            <?php } ?>

					            <?php 
					            if ($style == '') {
						            $link = vc_build_link( $shortcode_atts->link );
						            $link_target = ( ! empty( $link['target'] ) ) ? 'target="' . trim( $link['target'] ) . '"' : ''; 
						            if ( strlen( $shortcode_atts->link ) > 0 && strlen( $link['url'] ) > 0 ) { ?>
						            	<a href="<?php echo esc_attr( $link['url'] ); ?>" class="btn" <?php echo $link_target; ?>><span><?php echo esc_attr( $link['title'] ); ?></span><i class="fa fa-arrow-right"></i></a>
						            <?php }
						        } ?>

					        </div>
					</div>

		            <?php if ($style == 'inside') { ?>
		            <div class="enter-category col-md-12">
		            	<?php $link = vc_build_link( $shortcode_atts->link );
		            		  $link_target = ( ! empty( $link['target'] ) ) ? 'target="' . $link['target'] . '"' : ''; 
			            if ( strlen( $shortcode_atts->link ) > 0 && strlen( $link['url'] ) > 0 ) { ?>
			            	<a href="<?php echo esc_attr( $link['url'] ); ?>" class="btn" <?php echo $link_target; ?>><span><?php echo esc_attr( $link['title'] ); ?></span><i class="fa fa-arrow-right"></i></a>
			            <?php } ?>
			        </div>
			        <?php } ?>
				</div>
			<?php } ?>

			
		</div>
		<?php 
		return  ob_get_clean();
	}

}

/* Shortvode Item */

vc_map( array(
  'name'            => 'Alex Zane Simple Slider Item',
  'base'            => 'alex_vertical_slider_item',
  'as_child' 		=> array('only' => 'alex_vertical_slider'),
  'content_element' => true,
  'show_settings_on_create' => true,
  'description'     => 'Image, title and text',
  'params'          => array(
	  array(
	    'type'        => 'attach_image',
	    'heading'     => 'Image',
	    'param_name'  => 'image',
	    'admin_label' => true,
	    'description' => 'Upload your image.'
	  ),
	  array(
	    'type'        => 'attach_image',
	    'heading'     => 'Image Inside',
	    'param_name'  => 'image_inside',
	    'admin_label' => true,
	    'description' => 'Image for Inside Style.'
	  ),
	  array(
		'type'        => 'textfield',
		'heading'     => 'Subtitle',
		'param_name'  => 'subtitle',
		'admin_label' => true,
		'value'       => '',
		'description' => __( 'Subtitle slider item.', 'js_composer' ),
	  ),
	  array(
		'type'        => 'textfield',
		'heading'     => 'Title',
		'param_name'  => 'title',
		'admin_label' => true,
		'value'       => '',
		'description' => __( 'Title slider item.', 'js_composer' ),
	  ),
	  array(
		'type'        => 'textarea_html',
		'heading'     => 'Text',
		'param_name'  => 'content',
		'description' => __( 'Content slider item.', 'js_composer' ),
	  ),
	  array(
		'type' => 'vc_link',
		'heading' => __( 'URL (Link)', 'js_composer' ),
		'param_name' => 'link',
		'description' => __( 'Add link to slider item.', 'js_composer' ),
	 ),
	 array(
	 	'type' => 'textfield',
	 	'heading' => __( 'Extra class name', 'js_composer' ),
	 	'param_name' => 'el_class',
	 	'description' => __( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'js_composer' ),
	 	'value' => '',
	 ),
  ) //end params
) );


class WPBakeryShortCode_alex_vertical_slider_item extends WPBakeryShortCode{
	protected function content( $atts, $content = null ) {

		global $alex_shortcode_items;
		$alex_shortcode_items[] = array( 'atts' => $atts, 'content' => $content, 'css_class' => '');
		return;
	}
}