<?php 
/*
** Alex Zane Icons Shortcode
** Version: 1.0.0 
*/

vc_map( array(
	'name'                    => __( 'Alex Zane Icons', 'js_composer' ),
	'base'                    => 'alex_zend_social_icons',
	'content_element'         => true,
	'show_settings_on_create' => false,
	'category' 				  => __( 'From Alex Zane', 'js_composer' ),
	'description'             => __( 'Social Icon List', 'js_composer'),
	'params'          => array(
		array(
			'type'        => 'textfield',
			'heading'     => 'Title',
			'param_name'  => 'title',
			'admin_label' => true,
			'value'       => '',
		),
		
		array(
			'type' => 'param_group',
			'heading' => __( 'Group Params', 'js_composer' ),
			'param_name' => 'params_icon',
			'value' => '',
			'params' => array(
				array(
					'type' => 'dropdown',
					'heading' => __( 'Icon library', 'js_composer' ),
					'value' => array(
						__( 'Font Awesome', 'js_composer' ) => 'fontawesome',
						__( 'Open Iconic', 'js_composer' ) => 'openiconic',
						__( 'Typicons', 'js_composer' ) => 'typicons',
						__( 'Entypo', 'js_composer' ) => 'entypo',
						__( 'Linecons', 'js_composer' ) => 'linecons',
					),
					'admin_label' => true,
					'param_name' => 'type',
					'description' => __( 'Select icon library.', 'js_composer' ),
				),
				array(
					'type' => 'iconpicker',
					'heading' => __( 'Icon', 'js_composer' ),
					'param_name' => 'icon_fontawesome',
					'value' => 'fa fa-facebook-official fa-2x', // default value to backend editor admin_label
					'settings' => array(
						'emptyIcon' => false,
						// default true, display an "EMPTY" icon?
						'iconsPerPage' => 4000,
						// default 100, how many icons per/page to display, we use (big number) to display all icons in single page
					),
					'dependency' => array(
						'element' => 'type',
						'value' => 'fontawesome',
					),
					'description' => __( 'Select icon from library.', 'js_composer' ),
				),
				array(
					'type' => 'iconpicker',
					'heading' => __( 'Icon', 'js_composer' ),
					'param_name' => 'icon_openiconic',
					'value' => 'vc-oi vc-oi-dial', // default value to backend editor admin_label
					'settings' => array(
						'emptyIcon' => false, // default true, display an "EMPTY" icon?
						'type' => 'openiconic',
						'iconsPerPage' => 4000, // default 100, how many icons per/page to display
					),
					'dependency' => array(
						'element' => 'type',
						'value' => 'openiconic',
					),
					'description' => __( 'Select icon from library.', 'js_composer' ),
				),
				array(
					'type' => 'iconpicker',
					'heading' => __( 'Icon', 'js_composer' ),
					'param_name' => 'icon_typicons',
					'value' => 'typcn typcn-adjust-brightness', // default value to backend editor admin_label
					'settings' => array(
						'emptyIcon' => false, // default true, display an "EMPTY" icon?
						'type' => 'typicons',
						'iconsPerPage' => 4000, // default 100, how many icons per/page to display
					),
					'dependency' => array(
						'element' => 'type',
						'value' => 'typicons',
					),
					'description' => __( 'Select icon from library.', 'js_composer' ),
				),
				array(
					'type' => 'iconpicker',
					'heading' => __( 'Icon', 'js_composer' ),
					'param_name' => 'icon_entypo',
					'value' => 'entypo-icon entypo-icon-note', // default value to backend editor admin_label
					'settings' => array(
						'emptyIcon' => false, // default true, display an "EMPTY" icon?
						'type' => 'entypo',
						'iconsPerPage' => 4000, // default 100, how many icons per/page to display
					),
					'dependency' => array(
						'element' => 'type',
						'value' => 'entypo',
					),
				),
				array(
					'type' => 'iconpicker',
					'heading' => __( 'Icon', 'js_composer' ),
					'param_name' => 'icon_linecons',
					'value' => 'vc_li vc_li-heart', // default value to backend editor admin_label
					'settings' => array(
						'emptyIcon' => false, // default true, display an "EMPTY" icon?
						'type' => 'linecons',
						'iconsPerPage' => 4000, // default 100, how many icons per/page to display
					),
					'dependency' => array(
						'element' => 'type',
						'value' => 'linecons',
					),
					'description' => __( 'Select icon from library.', 'js_composer' ),
				),
				array(
					'type'        => 'href',
					'heading'     => 'Url',
					'param_name'  => 'url',
					'admin_label' => true,
					'value'       => '',
				),
			),
		),
		
		array(
			'type' => 'css_editor',
			'heading' => __( 'CSS box', 'js_composer' ),
			'param_name' => 'css',
			'group' => __( 'Design options', 'js_composer' ),
		),
	) //end params
) );

class WPBakeryShortCode_alex_zend_social_icons extends WPBakeryShortCode {

	protected function content( $atts, $content = null) {

		extract( shortcode_atts( array(
			'el_class'  => '',
			'title'     => '',
			'params_icon'  => '',
			'css'       => ''
		), $atts ) );

		$width_class = 'social-icons';
		$css_class = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, $width_class, $this->settings['base'], $atts );

		// custum css
		$css_class .= vc_shortcode_custom_css_class( $css, ' ' );

		// custum class
		$css_class .= ' '.$el_class;

		// parse param group
		$params_icon = (array) vc_param_group_parse_atts( $params_icon );

		// output
		ob_start();
		?>
		<!-- Social Icons -->
		<div class="<?php echo esc_attr($css_class); ?>">
			<?php if (! empty($title)){ ?>
				<h3><?php echo esc_html( $title ); ?></h3>
			<?php } ?>
			<?php foreach ($params_icon as $icon) {
				// Enqueue needed icon font.
				vc_icon_element_fonts_enqueue( $icon['type'] );
				$iconClass = $icon['icon_'.$icon['type']] ? esc_attr( $icon['icon_'.$icon['type']] ) : 'fa fa-facebook-official fa-2x'; ?>
				
				<a target="_blank" href="<?php echo esc_url($icon['url']); ?>" class="btn">
					<i class="fa vc_icon_element-icon <?php echo esc_attr($iconClass);  ?> fa-2x"></i>
				</a>

			<?php } ?>
		</div>
		<!-- /Social Icons -->

		<?php 
		return  ob_get_clean();
	}

}