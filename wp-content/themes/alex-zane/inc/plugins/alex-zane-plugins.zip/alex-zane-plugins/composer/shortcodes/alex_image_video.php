<?php 
/*
** Alex Zane Gallery Shortcode
** Version: 1.0.0 
*/

vc_map( array(
	'name'                    => esc_html__( 'Alex Zane Video and Images Gallery', 'js_composer' ),
	'base'                    => 'alex_zane_videos_images',
	'content_element'         => true,
	'show_settings_on_create' => false,
	'category' 				  => esc_html__( 'From Alex Zane', 'js_composer' ),
	'description'             => esc_html__( 'Gallery Videos and Images', 'js_composer'),
	'params'          => array(
		
		array(
			'type'        => 'param_group',
			'heading'     => 'Add Videos or Images',
			'param_name'  => 'items',
			'params'      => array(
				array(
					'type' => 'dropdown',
					'heading' => esc_html__( 'Type', 'js_composer' ),
					'param_name' => 'type_gallery',
					'value' => array(
						esc_html__( 'Image', 'js_composer' ) => 'image',
						esc_html__( 'Video', 'js_composer' ) => 'video',
					),
				),
				array(
					'type'        => 'attach_images',
					'heading'     => 'Image Event',
					'param_name'  => 'images',
					'admin_label' => true,
					'description' => 'Upload your image.',
					'dependency' => array(
						'element' => 'type_gallery',
						'value' => 'image',
					),
				),
				array(
					'type'        => 'textfield',
					'heading'     => 'Video Url',
					'description' => 'Url Youtube, Vimeo etc..(oembed support)',
					'param_name'  => 'video_url',
					'value'       => '',
					'dependency' => array(
						'element' => 'type_gallery',
						'value' => 'video',
					),
				),
				array(
					'type'        => 'attach_image',
					'heading'     => 'Video Preview',
					'param_name'  => 'video_preview',
					'dependency' => array(
						'element' => 'type_gallery',
						'value' => 'video',
					),
				),
			),
		),
		
		array(
			'type' => 'dropdown',
			'heading' => esc_html__( 'Column', 'js_composer' ),
			'param_name' => 'width',
			'value' => array(
				esc_html__( '2 columns - 1/6', 'js_composer' ) => '1/6',
				esc_html__( '3 columns - 1/4', 'js_composer' ) => '1/4',
				esc_html__( '4 columns - 1/3', 'js_composer' ) => '1/3',
			),
			'group' => esc_html__( 'Configuration', 'js_composer' ),
			'description' => esc_html__( 'Select column width.', 'js_composer' ),
			'std' => '1/6',
		),
		array(
			'type' => 'textfield',
			'heading' => esc_html__( 'Count Items', 'js_composer' ),
			'param_name' => 'count',
			'group' => esc_html__( 'Configuration', 'js_composer' ),
			'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'js_composer' ),
			'value' => '',
		),
		array(
			'type' => 'textfield',
			'heading' => esc_html__( 'Extra class name', 'js_composer' ),
			'param_name' => 'el_class',
			'group' => esc_html__( 'Configuration', 'js_composer' ),
			'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'js_composer' ),
			'value' => '',
		),
		array(
			'type' => 'css_editor',
			'heading' => esc_html__( 'CSS box', 'js_composer' ),
			'param_name' => 'css',
			'group' => esc_html__( 'Design options', 'js_composer' ),
		),
	) //end params
) );




class WPBakeryShortCode_alex_zane_videos_images extends WPBakeryShortCode {

	protected function content( $atts, $content = null ) {

		extract( shortcode_atts( array(
			'items' => '',
			'count'    => '',
			'width'         => '1/6',
			'el_class' 	=> '',
			'css' 			=> ''
		), $atts ) );

		// width column
		$width_class = array(
			'1/6' => 'col-md6 col-sm-6 col-xs-12',
			'1/4' => 'col-md4 col-sm-4 col-xs-12',
			'1/3' => 'col-md3 col-sm-3 col-xs-12'
		);

		// el class
		$css_classes = array(
			$this->getExtraClass( $el_class ),
			'masonry',
			'gallery',
			'row'
		);

		$css_class = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, implode( ' ', array_filter( $css_classes ) ), $this->settings['base'], $atts );

		// custum css
		$css_class .= vc_shortcode_custom_css_class( $css, ' ' );

		// custum class
		$css_class .= (!empty($css_class)) ? ' '.$css_class : '';

		// default image
		$default_src = vc_asset_url( 'vc/no_image.png' );

		// image config

		$image_sizes  = array(
			array('570','380'),
			array('570','570'),
			array('570','356'),
			array('570','321'),
			array('570','380'),
			array('570','570'),
			array('570','380'),
			array('570','356'),
			array('570','321'),
			array('570','380'),
			array('570','380'),
			array('570','380'),
			array('570','356'),
			array('570','321'),
			array('570','380'),
			array('570','356'),
			array('570','321'),
			);

		//create array
		$count = $count ? $count : count($items);

		function alex_the_thumbnile_by_id($image, $default_src,$image_size){
			$thumbnail = '';
			$thumbnail['large_src'] = wp_get_attachment_image_src( $image , 'full'  );
			if ( $image > 0 ) {
				$attachment = get_post( $image );
				$thumbnail['caption'] = $attachment->post_excerpt ? $attachment->post_excerpt : $attachment->post_title;
				$img = wp_get_attachment_image_src( $image , $image_size );
				$thumbnail['html'] = '<img src="' . esc_attr( $thumbnail['large_src'][0] ) . '" />';
			} else {
				$thumbnail['large_src'][0] = $default_src;
				$thumbnail['large_src'][1] = '570';
				$thumbnail['large_src'][2] = '570';
				$thumbnail['html'] = '<img src="' . esc_attr( $default_src ) . '" />';
			}

			return $thumbnail;
		}

		// get repeater
		$items = json_decode(urldecode($items));

		// 
		wp_enqueue_script( 'jquery.fitvids',      get_template_directory_uri()  . '/assets/js/jquery.fitvids.js',        array( 'jquery' ), false, true );


		// output
		ob_start();
		//print_r($items);
		?>

		<!-- Row -->
		<?php if (! empty($items) && is_array($items) ) : ?>
		<div class="<?php echo esc_attr( $css_class ); ?>">
			
			<?php foreach ( $items as $i => $item ) : ?>

				<!-- Grid Item-->
				<figure class="grid-item <?php echo esc_attr($width_class[$width]); ?>">
				
				<?php
				if ($item->type_gallery != 'video' && !empty($item->images)) { // for image
					$thumbnail = alex_the_thumbnile_by_id( $item->images, $default_src, $image_sizes[$i] ); ?>

					<a href="<?php echo esc_attr($thumbnail['large_src'][0] ); ?>" data-size="<?php echo esc_attr($thumbnail['large_src'][1]);?>x<?php echo esc_attr($thumbnail['large_src'][2]);?>">
						<?php echo $thumbnail['html']; ?>
					</a>
					<figcaption ><?php echo esc_html($thumbnail['caption']); ?></figcaption>

				<?php } else { // for video

					$thumbnail = alex_the_thumbnile_by_id( $item->video_preview = '', $default_src, $image_sizes[$i] );
					
					// oembed video
					$embed_code = wp_oembed_get($item->video_url);
					preg_match( '/src="([^"]*)"/i', $embed_code, $url_arr );
					if (isset( $url_arr ) && count($url_arr)){ 
					?>
					<a data-iframe="<?php echo esc_attr( $url_arr[1] ); ?>" href="<?php echo esc_attr($thumbnail['large_src'][0] ); ?>" 
					data-size="<?php echo esc_attr($thumbnail['large_src'][1]);?>x<?php echo esc_attr($thumbnail['large_src'][2]);?>"
					>
						<?php echo $thumbnail['html'];  ?>
					</a>
					<?php } ?>
					<?php if (! empty($thumbnail['caption']) ): ?>
					<figcaption ><?php echo esc_html($thumbnail['caption']); ?></figcaption>
					<?php endif ?>

				<?php } ?>
				</figure>

			<?php endforeach; ?>
		</div>

		<!-- Root element of PhotoSwipe. Must have class pswp. -->
		<div class="pswp" tabindex="-1" role="dialog" aria-hidden="true">
		    <!-- Background of PhotoSwipe. 
		         It's a separate element as animating opacity is faster than rgba(). -->
		    <div class="pswp__bg"></div>
		    <!-- Slides wrapper with overflow:hidden. -->
		    <div class="pswp__scroll-wrap">
		        <!-- Container that holds slides. 
		            PhotoSwipe keeps only 3 of them in the DOM to save memory.
		            Don't modify these 3 pswp__item elements, data is added later on. -->
		        <div class="pswp__container">
		            <div class="pswp__item"></div>
		            <div class="pswp__item"></div>
		            <div class="pswp__item"></div>
		        </div>
		        <!-- Default (PhotoSwipeUI_Default) interface on top of sliding area. Can be changed. -->
		        <div class="pswp__ui pswp__ui--hidden">
		            <div class="pswp__top-bar">
		                <!--  Controls are self-explanatory. Order can be changed. -->
		                <div class="pswp__counter"></div>
		                <button class="pswp__button pswp__button--close" title=" <?php echo esc_attr('Close (Esc)','alex-zane');?>"></button>
		                <button class="pswp__button pswp__button--share" title=" <?php echo esc_attr('Share','alex-zane');?>"></button>
		                <button class="pswp__button pswp__button--fs" title=" <?php echo esc_attr('Toggle fullscreen','alex-zane');?>"></button>
		                <button class="pswp__button pswp__button--zoom" title=" <?php echo esc_attr('Zoom in/out','alex-zane');?>"></button>
		                <!-- Preloader demo http://codepen.io/dimsemenov/pen/yyBWoR -->
		                <div class="pswp__preloader">
		                    <div class="pswp__preloader__icn">
		                      <div class="pswp__preloader__cut">
		                        <div class="pswp__preloader__donut"></div>
		                      </div>
		                    </div>
		                </div>
		            </div>
		            <div class="pswp__share-modal pswp__share-modal--hidden pswp__single-tap">
		                <div class="pswp__share-tooltip"></div> 
		            </div>
		            <button class="pswp__button pswp__button--arrow--left" title=" <?php echo esc_attr('Previous (arrow left)','alex-zane'); ?>">
		            </button>
		            <button class="pswp__button pswp__button--arrow--right" title=" <?php echo esc_attr('Next (arrow right)','alex-zane'); ?>">
		            </button>
		            <div class="pswp__caption">
		                <div class="pswp__caption__center"></div>
		            </div>
		        </div>
		    </div>
		</div>
		<!-- /Root element of PhotoSwipe. Must have class pswp. -->
		<?php endif; ?>

		<?php 
		return  ob_get_clean();
	}

}
