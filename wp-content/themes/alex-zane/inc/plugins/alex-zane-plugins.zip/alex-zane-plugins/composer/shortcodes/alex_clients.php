<?php 
/*
** Alex Zane Clients Shortcode
** Version: 1.0.0 
*/

vc_map( array(
	'name'                    => esc_html__( 'Alex Zane Clients', 'js_composer' ),
	'base'                    => 'alex_zane_clients',
	'content_element'         => true,
	'show_settings_on_create' => false,
	'category' 				  => esc_html__( 'From Alex Zane', 'js_composer' ),
	'description'             => esc_html__( 'Image Clients List', 'js_composer'),
	'params'          => array(
		array(
			'type'        => 'textfield',
			'heading'     => 'Title',
			'param_name'  => 'title',
			'admin_label' => true,
			'value'       => '',
		),
		
		array(
			'type' => 'param_group',
			'heading' => esc_html__( 'Group Params', 'js_composer' ),
			'param_name' => 'clients',
			'value' => '',
			'params' => array(
				array(
					'type'        => 'attach_image',
					'heading'     => 'Image',
					'param_name'  => 'image',
					'admin_label' => true,
					'value'       => '',
				),
				array(
					'type'        => 'href',
					'heading'     => 'Url',
					'param_name'  => 'url',
					'admin_label' => true,
					'value'       => '',
				),
			),
		),
		
		array(
			'type' => 'css_editor',
			'heading' => esc_html__( 'CSS box', 'js_composer' ),
			'param_name' => 'css',
			'group' => esc_html__( 'Design options', 'js_composer' ),
		),
	) //end params
) );

class WPBakeryShortCode_alex_zane_clients extends WPBakeryShortCode {

	protected function content( $atts, $content = null) {

		extract( shortcode_atts( array(
			'el_class'  => '',
			'title'     => '',
			'clients'  => '',
			'css'       => ''
		), $atts ) );

		$width_class = 'clients';
		$css_class = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, $width_class, $this->settings['base'], $atts );

		// custum css
		$css_class .= vc_shortcode_custom_css_class( $css, ' ' );

		// custum class
		$css_class .= ' '.$el_class;

		// parse param group
		$clients = (array) vc_param_group_parse_atts( $clients );

		// output
		ob_start();
		?>
		<!-- Clients -->
		<div class="<?php echo esc_attr($css_class); ?>">
			<?php if (! empty($title)){ ?>
				<h3><?php echo esc_html( $title ); ?></h3>
			<?php } ?>
			<?php foreach ($clients as $client) { ?>
				<a target="_blank" href="<?php echo esc_url($client['url']); ?>">
					<?php 
					if ($client['image']) {
						$img_src = wp_get_attachment_image_src( $client['image'] , 'full' ); ?>
						<img src="<?php echo esc_attr($img_src[0]); ?>" alt="">
					<?php } ?>
				</a>

			<?php } ?>
		</div>
		<!-- /Clients -->

		<?php 
		return  ob_get_clean();
	}

}