<?php 
/*
** Alex Zane Blog Shortcode
** Version: 1.0.0 
*/

vc_map( array(
	'name'                    => __( 'Alex Zane Blog', 'js_composer' ),
	'base'                    => 'alex_zane_blog',
	'content_element'         => true,
	'show_settings_on_create' => false,
	'category' 				  => __( 'From Alex Zane', 'js_composer' ),
	'description'             => __( 'Output Posts from Blog', 'js_composer'),
	'params'          => array(
		array(
			'type'        => 'textfield',
			'heading'     => 'Title',
			'param_name'  => 'title',
			'admin_label' => true,
			'value'       => '',
		),
		array(
			'type' => 'dropdown',
			'heading' => __( 'Style', 'js_composer' ),
			'param_name' => 'style_page',
			'value' => array(
				esc_html__( 'Full Width (Default)', 'js_composer' ) => '',
				esc_html__( 'Timeline', 'js_composer' ) => 'timeline'
			),
		),
		array(
			'type'        => 'textfield',
			'heading'     => 'Count Posts',
			'param_name'  => 'count',
			'admin_label' => true,
			'value'       => '',
		),
	
		
		array(
			'type' => 'css_editor',
			'heading' => __( 'CSS box', 'js_composer' ),
			'param_name' => 'css',
			'group' => __( 'Design options', 'js_composer' ),
		),
	) //end params
) );

class WPBakeryShortCode_alex_zane_blog extends WPBakeryShortCode {

	protected function content( $atts, $content = null) {

		extract( shortcode_atts( array(
			'el_class'  => '',
			'style_page'=> '',
			'title'     => '',
			'css'       => ''
		), $atts ) );

		$width_class = 'shortcode-blog';
		$css_class = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, $width_class, $this->settings['base'], $atts );

		// custum css
		$css_class .= vc_shortcode_custom_css_class( $css, ' ' );

		// custum class
		$css_class .= ' '.$el_class;

		// What page are we on? And what is the pages limit?
		$paged = ( get_query_var('paged') > 1 ) ? get_query_var('paged') : 1;

		// output
		ob_start();
		?>
		<div class="<?php echo esc_attr($css_class); ?>">
			<?php 
			$terms = get_terms('category');
			$categories = '';
			foreach ($terms as $term) {
				$categories .= $term->term_id.',';
			}

			$query_blog = new WP_Query(
				array( 
					'post_type' => 'post',
					'cat' => trim($categories,','),
					'paged' => $paged
				)
			); 

			global $wp_query;
			$max_page = $wp_query->max_num_pages;

			if ( $query_blog->have_posts() ) { ?>
			<div class="masonry row transition">
				<?php while ( $query_blog->have_posts() ) : $query_blog->the_post();
					global $post;
					setup_postdata( $post ); ?>
					<!-- Blog Item -->
					<?php 
					$format = get_post_format();
					$format = ( $format === false) ? 'default' : $format;
					$classes_post =  'format-' . get_post_format() . ' blog-content-item';
					$classes_post .= $style_page ? ' ' . $style_page . ' col-md6 col-sm-6 col-xs-12' : ' blog-item';
					?>
					<div <?php post_class( esc_attr( $classes_post) ); ?>>

						<?php 
						if( is_sticky() ){  ?>
						<i title="<?php esc_html_e( 'Sticky Post', 'alex-zane' ); ?>" class="sticky-icon fa fa-thumb-tack fa-2x"></i>
						<?php }
						// get template format
						get_template_part('template-parts/content', $format);
						?>
						
					</div>
					<!-- /Blog Item -->
					<?php
					endwhile;
				}else {
					esc_html_e( 'no posts','alex-zane' );
				}
				?>
		</div>
		<ul class="pager">
			<?php if ( get_previous_posts_link() ){ ?>
			<li class="prev">
				<?php previous_posts_link( esc_html__('Previous','alex-zane') ); ?>
			</li>
			<?php  } ?>
			<?php if ( get_next_posts_link('', $query_blog->max_num_pages) ){ ?>
			<li class="next">
				<?php next_posts_link( esc_html__('Next', 'alex-zane'), $query_blog->max_num_pages ); ?>
			</li>
			<?php } ?>
		</ul>
		<?php 
		wp_reset_postdata();
		return  ob_get_clean();
	}

}