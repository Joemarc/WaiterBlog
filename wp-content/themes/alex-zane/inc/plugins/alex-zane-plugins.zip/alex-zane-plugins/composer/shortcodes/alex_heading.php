<?php 
/*
** Alex Zane Heading Shortcode
** Version: 1.0.0 
*/

vc_map( array(
	'name'                    => esc_html__( 'Alex Zend Heading', 'js_composer' ),
	'base'                    => 'alex_zend_heading',
	'content_element'         => true,
	'show_settings_on_create' => true,
	'category' 				  => esc_html__( 'From Alex Zane', 'js_composer' ),
	'description'             => esc_html__( 'Title and content', 'js_composer'),
	'params'          => array(
		array(
			'type'        => 'textfield',
			'heading'     => 'Title',
			'param_name'  => 'title',
			'admin_label' => true,
			'value'       => '',
		),
		array(
			'type'        => 'textarea_html',
			'heading'     => 'Text',
			'param_name'  => 'content',
			'value'       => '',
		),
		array(
			'type' => 'dropdown',
			'heading' => esc_html__( 'Align', 'js_composer' ),
			'param_name' => 'align',
			'value' => array(
				esc_html__( 'Left', 'js_composer' ) => '',
				esc_html__( 'Center', 'js_composer' ) => 'text-center',
				esc_html__( 'Right', 'js_composer' ) => 'text-right',
			),
		),
		array(
			'type' => 'textfield',
			'heading' => esc_html__( 'Extra class name', 'js_composer' ),
			'param_name' => 'el_class',
			'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'js_composer' ),
			'value' => '',
		),
		array(
			'type' => 'css_editor',
			'heading' => esc_html__( 'CSS box', 'js_composer' ),
			'param_name' => 'css',
			'group' => esc_html__( 'Design options', 'js_composer' ),
		),
	) //end params
) );

class WPBakeryShortCode_alex_zend_heading extends WPBakeryShortCode{
	protected function content( $atts, $content = null ) {

		extract( shortcode_atts( array(
			'subtitle'  => '',
			'title' 	=> '',
			'el_class'  => '',
			'align'     => '',
			'css'       => ''
		), $atts ) );

		$width_class = ($align != '') ? $align : 'alex_zane_heading';
		$css_class = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, $width_class, $this->settings['base'], $atts );
		
		// custum css
		$css_class .= vc_shortcode_custom_css_class( $css, ' ' );

		// custum class
		$css_class .= (!empty($el_class)) ? ' '.$el_class : '';

		// output
		$output = '<div class="' . esc_attr( $css_class ) . '">';
		if (! empty($title)) {
			$output .= '<h3>' . esc_html($title) . '</h3>';
		}
		$output .= wpautop( do_shortcode( $content ) );
		$output .= '</div>';

		// return output
		return  $output;

	}
}
